# LeafcuraFix

LeafcuraFix ist eine zweisprachige (DE/EN) WebApp zur Diagnose von Pflanzenproblemen anhand von Blattbildern – mit Empfehlungen für haushaltsübliche Lösungen.